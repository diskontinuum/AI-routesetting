# AI-routesetting
Setting intelligent climbing routes - artificially.
